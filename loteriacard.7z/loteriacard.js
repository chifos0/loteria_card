// Adapted from code provided by SparoHawk from Stack Overflow
// https://stackoverflow.com/questions/22254608/change-image-based-on-dropdown-using-javascript

// This is the code to preload the images
let imageList = Array();
for (let i = 1; i <= 54; i++) {
  imageList[i] = new Image(300, 420);
  imageList[i].src = "images/loteria 5x7 " + i + ".jpg";
}

// 16 functions...hope to eventually learn how to cut this down to 1 function to control all 16 squares. Would be much neater code!
// At least I got rid of all the uses of 'var'!

function switchImage() {
  let selectedImage =
    document.myForm.switch.options[document.myForm.switch.selectedIndex].value;
  document.myImage.src = imageList[selectedImage].src;
}

function switchImage2() {
  let selectedImage =
    document.myForm2.switch2.options[document.myForm2.switch2.selectedIndex]
      .value;
  document.myImage2.src = imageList[selectedImage].src;
}

function switchImage3() {
  let selectedImage =
    document.myForm3.switch3.options[document.myForm3.switch3.selectedIndex]
      .value;
  document.myImage3.src = imageList[selectedImage].src;
}

function switchImage4() {
  let selectedImage =
    document.myForm4.switch4.options[document.myForm4.switch4.selectedIndex]
      .value;
  document.myImage4.src = imageList[selectedImage].src;
}

function switchImage5() {
  let selectedImage =
    document.myForm5.switch5.options[document.myForm5.switch5.selectedIndex]
      .value;
  document.myImage5.src = imageList[selectedImage].src;
}

function switchImage6() {
  let selectedImage =
    document.myForm6.switch6.options[document.myForm6.switch6.selectedIndex]
      .value;
  document.myImage6.src = imageList[selectedImage].src;
}

function switchImage7() {
  let selectedImage =
    document.myForm7.switch7.options[document.myForm7.switch7.selectedIndex]
      .value;
  document.myImage7.src = imageList[selectedImage].src;
}

function switchImage8() {
  let selectedImage =
    document.myForm8.switch8.options[document.myForm8.switch8.selectedIndex]
      .value;
  document.myImage8.src = imageList[selectedImage].src;
}

function switchImage9() {
  let selectedImage =
    document.myForm9.switch9.options[document.myForm9.switch9.selectedIndex]
      .value;
  document.myImage9.src = imageList[selectedImage].src;
}

function switchImage10() {
  let selectedImage =
    document.myForm10.switch10.options[document.myForm10.switch10.selectedIndex]
      .value;
  document.myImage10.src = imageList[selectedImage].src;
}

function switchImage11() {
  let selectedImage =
    document.myForm11.switch11.options[document.myForm11.switch11.selectedIndex]
      .value;
  document.myImage11.src = imageList[selectedImage].src;
}

function switchImage12() {
  let selectedImage =
    document.myForm12.switch12.options[document.myForm12.switch12.selectedIndex]
      .value;
  document.myImage12.src = imageList[selectedImage].src;
}

function switchImage13() {
  let selectedImage =
    document.myForm13.switch13.options[document.myForm13.switch13.selectedIndex]
      .value;
  document.myImage13.src = imageList[selectedImage].src;
}

function switchImage14() {
  let selectedImage =
    document.myForm14.switch14.options[document.myForm14.switch14.selectedIndex]
      .value;
  document.myImage14.src = imageList[selectedImage].src;
}

function switchImage15() {
  let selectedImage =
    document.myForm15.switch15.options[document.myForm15.switch15.selectedIndex]
      .value;
  document.myImage15.src = imageList[selectedImage].src;
}

function switchImage16() {
  let selectedImage =
    document.myForm16.switch16.options[document.myForm16.switch16.selectedIndex]
      .value;
  document.myImage16.src = imageList[selectedImage].src;
}
